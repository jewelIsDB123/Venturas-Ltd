﻿using System.Collections.Generic;
using VENTURASLTD.Models.Classes;
using VENTURASLTD.Models.ViewModels;

namespace VENTURASLTD.BLL.Interfaces
{
    public interface IRepository
    {
        List<ItemListViewModel> GetItemList();
        List<CreateItemModel> GetCreateItemModels();
        void UpdateItem(Item obj);
        void SaveItem(Item obj);
        void DeleteItem(int id);
        Item GetItemById(int id);
        List<Category> GetCategorys();
        void SaveCategory(Category obj);
        void UpdateCategory(Category obj);
        Category GetCategoryById(int CategoryID);
        void DeleteCategory(int id);
    }
}
