﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using VENTURASLTD.BLL.Interfaces;
using VENTURASLTD.Data;
using VENTURASLTD.Models.Classes;
using VENTURASLTD.Models.ViewModels;

namespace VENTURASLTD.BLL.Repository
{
    public class Repository : IRepository
    {
        private readonly AppDbContext _context;

        public Repository(AppDbContext context)
        {
            _context = context;
        }
        public void DeleteItem(int id)
        {
            Item delItem = GetItemById(id);
            _context.Items.Remove(delItem);
            _context.SaveChanges();
        }
        public void DeleteCategory(int id)
        {
            Category delCategory = GetCategoryById(id);
            _context.Categorys.Remove(delCategory);
            _context.SaveChanges();
        }

        public List<CreateItemModel> GetCreateItemModels()
        {
            List<CreateItemModel> createItemModels = new List<CreateItemModel>();
            createItemModels = _context.Items.Select(p => new CreateItemModel
            {
                ItemId=p.ItemId,
                ItemName=p.ItemName,
                ItemCreateDate=p.ItemCreateDate,
                SupCategoryName=p.SupCategoryName,
                MainCategoryName=p.MainCategoryName,
                CategoryId=p.CategoryId
            }).ToList();
            return createItemModels;
        }

        public Item GetItemById(int id)
        {

            Item Item = _context.Items.SingleOrDefault(p => p.ItemId == id);
            return Item;
        }

        public List<ItemListViewModel> GetItemList()
        {
            List<ItemListViewModel> list = _context.Items.Select(p => new ItemListViewModel
            {
                ItemId = p.ItemId,
                ItemName = p.ItemName,
                ItemCreateDate = p.ItemCreateDate,
                SupCategoryName = p.SupCategoryName,
                MainCategoryName = p.MainCategoryName,
                CategoryId = p.CategoryId,
                CategoryName = p.Category.CategoryName,
            }).ToList();
            return list;
        }
        public Category GetCategoryById(int CategoryId)
        {
            Category category = _context.Categorys.SingleOrDefault(g => g.CategoryId == CategoryId);
            return category;
        }
        public List<Category> GetCategorys()
        {
            List<Category> CategoryTypeList = _context.Categorys.ToList();
            return CategoryTypeList;
        }
        public void SaveItem(Item obj)
        {
            _context.Items.Add(obj);
            _context.SaveChanges();
        }
        public void SaveCategory(Category obj)
        {
            _context.Categorys.Add(obj);
            _context.SaveChanges();
        }

        public void UpdateItem(Item obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public void UpdateCategory(Category obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
