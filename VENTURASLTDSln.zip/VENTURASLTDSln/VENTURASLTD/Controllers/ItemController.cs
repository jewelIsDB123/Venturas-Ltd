﻿using Microsoft.AspNetCore.Mvc;
using PagedList;
using System.Collections.Generic;
using System.Linq;
using VENTURASLTD.BLL.Interfaces;
using VENTURASLTD.Data;
using VENTURASLTD.Models.Classes;
using VENTURASLTD.Models.ViewModels;

namespace VENTURASLTD.Controllers
{
    public class ItemController : Controller
    {
        private readonly IRepository _repoObj;
        private readonly AppDbContext _context;
        public ItemController(IRepository repoObj, AppDbContext context)
        {
            _repoObj = repoObj;
            _context = context;
        }
        public ActionResult Index(string SearchString, string CurrentFilter, string sortOrder, int? Page)
        {
            ViewBag.SortNameParam = string.IsNullOrEmpty(sortOrder) ? "name_des" : "";
            ViewBag.Salary = string.IsNullOrEmpty(sortOrder) ? "ItemId_des" : "";
            if (SearchString != null)
            {
                Page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            ViewBag.CurrentFilter = SearchString;

            List<ItemListViewModel> ItemList = _repoObj.GetItemList();

            if (!string.IsNullOrEmpty(SearchString))
            {
                ItemList = ItemList.Where(n => n.ItemName.ToUpper().Contains(SearchString.ToUpper())).ToList();
            }
            switch (sortOrder)
            {
                case "name_des":
                    ItemList = ItemList.OrderByDescending(n => n.ItemName).ToList();
                    break;
                case "ItemId_des":
                    ItemList = ItemList.OrderByDescending(n => n.ItemName).ToList();
                    break;
                default:
                    ItemList = ItemList.OrderBy(n => n.ItemName).ToList();
                    break;
            }
            int PageSize = 6;
            int PageNumber = (Page ?? 1);
            return View("Index", ItemList.ToPagedList(PageNumber, PageSize));
        }
        public ActionResult Create()
        {
            CreateItemModel crObj = new CreateItemModel();
            crObj.CategoryList = _context.Categorys.ToList();
            return View(crObj);
        }
        public ActionResult AddOrEdit(CreateItemModel viewObj)
        {
            var result = false;
            Item ItemObj = new Item();
            ItemObj.ItemName = viewObj.ItemName;
            ItemObj.ItemCreateDate = viewObj.ItemCreateDate;
            ItemObj.SupCategoryName = viewObj.SupCategoryName;
            ItemObj.MainCategoryName = viewObj.MainCategoryName;
            ItemObj.CategoryId = viewObj.CategoryId;
            if (ModelState.IsValid)
            {
                if (viewObj.ItemId == 0)
                {
                    _repoObj.SaveItem(ItemObj);
                    result = true;
                }
                else
                {
                    ItemObj.ItemId = viewObj.ItemId;
                    _repoObj.UpdateItem(ItemObj);
                    result = true;
                }
            }
            if (result)
            {
                TempData["AlertMessage"] = " Item Save Successfully...!";
                return RedirectToAction("Index");
            }
            else
            {
                if (viewObj.ItemId == 0)
                {
                    CreateItemModel crObj = new CreateItemModel();
                    crObj.CategoryList = _context.Categorys.ToList();
                    return View("Create", crObj);
                }
                else
                {
                    CreateItemModel crObj = new CreateItemModel();
                    crObj.CategoryList = _context.Categorys.ToList();
                    return View("Edit", crObj);
                }
            }
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Item ItemObj = _repoObj.GetItemById(id);
            CreateItemModel viewObj = new CreateItemModel();
            if (ItemObj != null)
            {
                viewObj.ItemId = ItemObj.ItemId;
                viewObj.ItemName = ItemObj.ItemName;
                viewObj.ItemCreateDate = ItemObj.ItemCreateDate;
                viewObj.SupCategoryName = ItemObj.SupCategoryName;
                viewObj.MainCategoryName = ItemObj.MainCategoryName;
                viewObj.CategoryId = ItemObj.CategoryId;
                viewObj.CategoryList = _context.Categorys.ToList();
            }
            return View(viewObj);
        }
        public ActionResult Delete(int id)
        {
            Item itemobj = _repoObj.GetItemById(id);
            if (itemobj != null)
            {
                _repoObj.DeleteItem(itemobj.CategoryId);
                 TempData["AlertMessage"] = " Item Delete Successfully...!";
                return RedirectToAction("Index");
            }
            return View(itemobj);
        }
    }
}

