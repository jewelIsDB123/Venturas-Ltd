﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using VENTURASLTD.BLL.Interfaces;
using VENTURASLTD.Data;
using VENTURASLTD.Models.Classes;
using VENTURASLTD.Models.ViewModels;

namespace VENTURASLTD.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IRepository _repoObj;
        private readonly AppDbContext _context;

        public CategoryController(IRepository repoObj, AppDbContext context)
        {
            _repoObj = repoObj;
            _context = context;
        }
        public ActionResult Index()
        {
            List<Category> CategoryList = _repoObj.GetCategorys();
            return View(CategoryList);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(CreateCategoryViewModel viewobj)
        {
            Category CategoryObj = new Category();
            CategoryObj.CategoryName = viewobj.CategoryName;
            CategoryObj.CategoryDetails = viewobj.CategoryDetails;
            CategoryObj.CategoryColar = viewobj.CategoryColar;
            _repoObj.SaveCategory(CategoryObj);
            TempData["AlertMessage"] = " Category Save Successfully...!";
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Category CategoryObj = _context.Categorys.SingleOrDefault(g => g.CategoryId == id);
            CreateCategoryViewModel CategoryObj2 = new CreateCategoryViewModel();
            if (CategoryObj != null)
            {
                CategoryObj2.CategoryName = CategoryObj.CategoryName;
                CategoryObj2.CategoryDetails = CategoryObj.CategoryDetails;
                CategoryObj2.CategoryColar = CategoryObj.CategoryColar;
            }
            return View(CategoryObj);
        }
        [HttpPost]
        public ActionResult Edit(CreateCategoryViewModel viewObj)
        {
            Category CategoryObj = new Category();
            CategoryObj.CategoryId = viewObj.CategoryId;
            CategoryObj.CategoryName = viewObj.CategoryName;
            CategoryObj.CategoryDetails = viewObj.CategoryDetails;
            CategoryObj.CategoryColar = viewObj.CategoryColar;
            _repoObj.UpdateCategory(CategoryObj);
            TempData["AlertMessage"] = " Category Edit Successfully...!";
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
         {
            Category Categoryobj = _repoObj.GetCategoryById(id);
            if (Categoryobj != null)
            {
                _repoObj.DeleteCategory(Categoryobj.CategoryId);
                TempData["AlertMessage"] = " Category Delete Successfully...!";
                return RedirectToAction("Index");
            }
            return View(Categoryobj);
        }
    }
}
