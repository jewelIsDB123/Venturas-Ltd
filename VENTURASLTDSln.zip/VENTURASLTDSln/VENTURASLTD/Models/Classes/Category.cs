﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VENTURASLTD.Models.Classes
{
    public class Category
    {

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDetails { get; set; }
        public string CategoryColar { get; set; }
        public virtual ICollection<Item> Items { get; set; }
    }
}
