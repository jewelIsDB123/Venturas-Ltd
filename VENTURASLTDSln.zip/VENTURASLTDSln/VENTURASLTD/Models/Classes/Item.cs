﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VENTURASLTD.Models.Classes
{
    public class Item
    {

        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public DateTime ItemCreateDate { get; set; }
        public string SupCategoryName { get; set; }
        public string MainCategoryName { get; set; }
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
    }
}
