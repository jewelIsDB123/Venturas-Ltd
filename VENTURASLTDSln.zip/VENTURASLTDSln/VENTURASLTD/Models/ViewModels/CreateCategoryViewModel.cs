﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using VENTURASLTD.Models.Classes;

namespace VENTURASLTD.Models.ViewModels
{
    public class CreateCategoryViewModel
    {
        public int CategoryId { get; set; }
        [Required(ErrorMessage = "CategoryName Is Required")]
        public string CategoryName { get; set; }
        public string CategoryDetails { get; set; }
        public string CategoryColar { get; set; }
    }
}
