﻿using PamirBangladeshLimited.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using VENTURASLTD.Models.Classes;

namespace VENTURASLTD.Models.ViewModels
{
    public class CreateItemModel
    {
        public int ItemId { get; set; }
        [Required(ErrorMessage = "ItemName Is Required")]
        [DataType(DataType.Text)]
        [Display(Name = "ItemName")]
        [StringLength(50, ErrorMessage = "ItemName Must be within 50 Charecter")]
        public string ItemName { get; set; }
        [CustomDateOfBirth(ErrorMessage = "Date of Birth must be less than or equal to Today's Date")]
        public DateTime ItemCreateDate { get; set; }
        [Required(ErrorMessage = "SupCategoryName Is Required")]
        public string SupCategoryName { get; set; }
        [Required(ErrorMessage = "MainCategoryName Is Required")]
        public string MainCategoryName { get; set; }
       
        [Display(Name = "CategoryName")]
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public List<Category> CategoryList { get; set; }
    }
}
