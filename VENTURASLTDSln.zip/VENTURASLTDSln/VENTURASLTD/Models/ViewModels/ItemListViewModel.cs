﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using VENTURASLTD.Models.Classes;

namespace VENTURASLTD.Models.ViewModels
{
    public class ItemListViewModel
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public DateTime ItemCreateDate { get; set; }
        public string SupCategoryName { get; set; }
        public string MainCategoryName { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public virtual Category Category { get; set; }
    }
}
