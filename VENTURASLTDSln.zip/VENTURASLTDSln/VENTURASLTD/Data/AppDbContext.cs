﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using VENTURASLTD.Models.Classes;


namespace VENTURASLTD.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<Category> Categorys { get; set; }
        public DbSet<Item> Items { get; set; }
    }
}

