Database Name Change then

Add-Migration init

Update-database